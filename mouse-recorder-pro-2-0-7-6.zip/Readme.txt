Mouse Recorder Pro 2 is a recording application which
will record your computer movements.
Mouse Recorder Pro 2 records your Keyboard and Mouse input.
This allows the user to repeat an operation easily and fast.
You can play what you have been recording whenever you like easier and faster.
You will be able to edit what you have been recording for further development

Features:

- user friendly.
- small sized.
- variaty of configuration options.
- make your script perform faster and easier using included functions.
- set a script to be played in a specific time using the Mouse Recorder Pro Calendar.
- edit your scripts by using the Mouse Recorder Pro Editor.

Mouse Recorder Pro 2 Video Tutorials can be found at this URL:
http://www.youtube.com/user/shynet#p/u

Notes:
Please uninstall any other version of Mouse Recorder Pro (2).

By Shynet �

Nemex 2010 , visit us at : http://byshynet.com .

Contact us at : shynet@gmail.com .